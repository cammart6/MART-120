function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);

  //title
  fill(0);
  textSize(20);
  textAlign(CENTER);
  text("My Portrait", width / 2, 30);

  //face
  fill(255, 220, 180); // Skin tone
  stroke(0);
  ellipse(200, 200, 150, 180); 

  //hair
  fill(50, 30, 0);
  rectMode(CENTER);
  rect(200, 130, 150, 40); 
  rect(130, 170, 10, 50)
  rect(270, 170, 10, 50)

  //eyes
  fill(255);
  ellipse(170, 180, 30, 20); // Left eye
  ellipse(230, 180, 30, 20); // Right eye
  fill(0);
  circle(170, 180, 10);      // Left pupil
  circle(230, 180, 10);      // Right pupil

  //nose
  noFill()
  triangle(180,220,220,220,200,190)
  strokeWeight(4);
  point(190, 215);
  point(210, 215);
  strokeWeight(1); 


  line(180, 250, 220, 250);

  //signature
  fill(50);
  textSize(16);
  textAlign(RIGHT);
  text("- Cameron Martin", 380, 380);
}