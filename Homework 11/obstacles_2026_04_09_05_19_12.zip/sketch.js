var player;
var obstacles = [];
var staticObstacle = null;
var won = false;

function setup() {
  createCanvas(600, 400);
  player = { x: 50, y: 50, size: 20 };

  // obstacles
  obstacles.push({ x: 200, y: 200, size: 40, color: 'red', speedX: 2, speedY: 1 });
  obstacles.push({ x: 400, y: 100, size: 60, color: 'blue', speedX: -1, speedY: 2 });
}

function draw() {
  background(220);

  if (won) {
    fill(0);
    textSize(32);
    textAlign(CENTER, CENTER);
    text("YOU WON!", width / 2, height / 2);
    return; 
  }

  // exit
  fill(0, 255, 0);
  rect(540, 340, 40, 40); 
  fill(0);
  text("EXIT", 547, 365);

  // movement
  if (keyIsDown(LEFT_ARROW)) player.x -= 3;
  if (keyIsDown(RIGHT_ARROW)) player.x += 3;
  if (keyIsDown(UP_ARROW)) player.y -= 3;
  if (keyIsDown(DOWN_ARROW)) player.y += 3;

  // player
  fill(255, 200, 0);
  ellipse(player.x, player.y, player.size);

  for (let obs of obstacles) {
    fill(obs.color);
    rect(obs.x, obs.y, obs.size, obs.size);

    obs.x += obs.speedX;
    obs.y += obs.speedY;

    if (obs.x > width) obs.x = -obs.size;
    else if (obs.x < -obs.size) obs.x = width;

    if (obs.y > height) obs.y = -obs.size;
    else if (obs.y < -obs.size) obs.y = height;
  }

  if (staticObstacle !== null) {
    fill(100);
    rect(staticObstacle.x, staticObstacle.y, 50, 50);
  }

  // win
  if (player.x > 540 && player.x < 580 && player.y > 340 && player.y < 380) {
    won = true;
  } else {
    // Just a placeholder to demonstrate if/else usage
    won = false;
  }
}

function mousePressed() {
  staticObstacle = { x: mouseX, y: mouseY };
}