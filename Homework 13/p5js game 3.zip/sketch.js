var player;
var obstacles = [];
var staticObstacles = []; 
var exit;
var gameWon = false;

function setup() {
  createCanvas(600, 400);
  createPlayer();
  createObstacles(); 
  createExit();
}

function draw() {
  background(220);
  
  if (gameWon) {
    displayWinMessage();
  } else {
    drawBorder();
    drawExit();
    handleStaticObstacles();
    movePlayer();
    displayPlayer();
    handleMovingObstacles();
    checkWin();
  }
}


function createPlayer() {
  player = { x: 50, y: 50, size: 20, speed: 5 };
}


function movePlayer() {
  if (keyIsDown(LEFT_ARROW)) player.x -= player.speed;
  if (keyIsDown(RIGHT_ARROW)) player.x += player.speed;
  if (keyIsDown(UP_ARROW)) player.y -= player.speed;
  if (keyIsDown(DOWN_ARROW)) player.y += player.speed;
}

function displayPlayer() {
  fill(0, 0, 255);
  circle(player.x, player.y, player.size);
}


function mousePressed() {
  
  staticObstacles.push({ x: mouseX, y: mouseY });
}

function handleStaticObstacles() {
  for (let i = 0; i < staticObstacles.length; i++) {
    fill(100);
    rect(staticObstacles[i].x - 10, staticObstacles[i].y - 10, 20, 20);
  }
}


function createObstacles() {
  let colors = ['red', 'green', 'purple', 'teal', 'orange', 'pink'];
  for (let i = 0; i < 6; i++) {
    obstacles.push({
      x: random(width),
      y: random(height),
      w: random(20, 50),
      h: random(20, 50),
      col: random(colors),
      sx: random(-3, 3),
      sy: random(-3, 3)
    });
  }
}


function handleMovingObstacles() {
  for (let i = 0; i < obstacles.length; i++) {
    let obs = obstacles[i];
    fill(obs.col);
    rect(obs.x, obs.y, obs.w, obs.h);

    obs.x += obs.sx;
    obs.y += obs.sy;

    if (obs.x > width) {
      obs.x = 0;
    } else if (obs.x < 0) {
      obs.x = width;
    }

    if (obs.y > height) {
      obs.y = 0;
    } else if (obs.y < 0) {
      obs.y = height;
    }
  }
}


function drawBorder() {
  stroke(0);
  strokeWeight(10);
  noFill();
  rect(0, 0, width, height);
  noStroke();
}


function createExit() {
  exit = { x: 540, y: 340, w: 40, h: 40 };
}

function drawExit() {
  fill(0, 255, 0);
  rect(exit.x, exit.y, exit.w, exit.h);
}


function checkWin() {
  
  if (player.x > exit.x && player.x < exit.x + exit.w && 
      player.y > exit.y && player.y < exit.y + exit.h) {
    gameWon = true;
  }
}

function displayWinMessage() {
  fill(0);
  textSize(40);
  textAlign(CENTER, CENTER);
  text("YOU WIN!", width / 2, height / 2);
}