var player;
var obs1, obs2;
var staticObstacle = null;
var exit;
var gameWon = false;

function setup() {
  createCanvas(600, 400);
  createPlayer();
  createObstacles();
  createExit();
}

function draw() {
  background(220); 
  drawBorder();
  drawExit();
  handleStaticObstacle();
  movePlayer();
  displayPlayer();
  
 
  moveObstacleOne();
  moveObstacleTwo();
  
  displayObstacles();
  checkWinCondition();
}


function createPlayer() {
  player = { x: 50, y: 50, size: 20, speed: 5 };
}


function movePlayer() {
  if (keyIsDown(LEFT_ARROW)) player.x -= player.speed;
  if (keyIsDown(RIGHT_ARROW)) player.x += player.speed;
  if (keyIsDown(UP_ARROW)) player.y -= player.speed;
  if (keyIsDown(DOWN_ARROW)) player.y += player.speed;
}

function displayPlayer() {
  fill(0, 0, 255);
  circle(player.x, player.y, player.size);
}


function mousePressed() {
  staticObstacle = { x: mouseX, y: mouseY };
}

function handleStaticObstacle() {
  if (staticObstacle !== null) {
    fill(255, 165, 0);
    rect(staticObstacle.x - 15, staticObstacle.y - 15, 30, 30);
  }
}


function createObstacles() {
  obs1 = { x: 100, y: 100, w: 40, h: 40, col: 'red', sx: 3, sy: 2 };
  obs2 = { x: 300, y: 200, w: 70, h: 30, col: 'purple', sx: -2, sy: 3 };
}


function moveObstacleOne() {
  obs1.x += obs1.sx;
  obs1.y += obs1.sy;

  if (obs1.x > width) obs1.x = 0;
  else if (obs1.x < 0) obs1.x = width;

  if (obs1.y > height) obs1.y = 0;
  else if (obs1.y < 0) obs1.y = height;
}

function moveObstacleTwo() {
  obs2.x += obs2.sx;
  obs2.y += obs2.sy;

  if (obs2.x > width) obs2.x = 0;
  else if (obs2.x < 0) obs2.x = width;

  if (obs2.y > height) obs2.y = 0;
  else if (obs2.y < 0) obs2.y = height;
}

function displayObstacles() {
  fill(obs1.col);
  rect(obs1.x, obs1.y, obs1.w, obs1.h);
  fill(obs2.col);
  rect(obs2.x, obs2.y, obs2.w, obs2.h);
}


function drawBorder() {
  stroke(0);
  strokeWeight(10);
  noFill();
  rect(0, 0, width, height);
  noStroke();
}


function createExit() {
  exit = { x: 530, y: 330, w: 50, h: 50 };
}

function drawExit() {
  fill(0, 255, 0);
  rect(exit.x, exit.y, exit.w, exit.h);
  fill(0);
  textAlign(CENTER, CENTER);
  text("EXIT", exit.x + exit.w / 2, exit.y + exit.h / 2);
}


function checkWinCondition() {
  if (player.x > exit.x && player.x < exit.x + exit.w && player.y > exit.y && player.y < exit.y + exit.h) {
    displayWin();
    noLoop(); // Stops the game once won
  }
}

function displayWin() {
  background(255);
  fill(0);
  textSize(40);
  textAlign(CENTER, CENTER);
  text("YOU WIN!", width / 2, height / 2);
}