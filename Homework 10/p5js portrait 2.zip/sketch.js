// variables
var eyeX = 170;
var eyeSpeed = 2; 

var nostrilY = 215;
var nostrilSpeed = 1.5; 

var pupilX = 170;
var pupilY = 180;
var pupilSpeedX = 3; 
var pupilSpeedY = 2; 

var titleSize = 20;
var titleGrowth = 0.5;
var growthCounter = 0;

function setup() {
  createCanvas(400, 400);
  eyeSpeed = random(1, 4);
  nostrilSpeed = random(1, 3);
}

function draw() {
  background(220);


  
  // title size
  titleSize += titleGrowth;
  growthCounter++;
  if (growthCounter >= 100) {
    titleGrowth *= -1;
    growthCounter = 0;
  }

  // eye movement
  eyeX += eyeSpeed;
  if (eyeX > 180 || eyeX < 160) eyeSpeed *= -1;

  // nostril movement
  nostrilY += nostrilSpeed;
  if (nostrilY > 220 || nostrilY < 210) nostrilSpeed *= -1;


  pupilX += pupilSpeedX;
  pupilY += pupilSpeedY;
  if (pupilX > 175 || pupilX < 165) pupilSpeedX *= -1;
  if (pupilY > 185 || pupilY < 175) pupilSpeedY *= -1;


  // title
  fill(0);
  textSize(titleSize);
  textAlign(CENTER);
  text("My Portrait", width / 2, 40);

  // face
  fill(255, 220, 180);
  stroke(0);
  ellipse(200, 200, 150, 180); 

  // hair
  fill(50, 30, 0);
  rectMode(CENTER);
  rect(200, 130, 150, 40); 
  rect(130, 170, 10, 50);
  rect(270, 170, 10, 50);

  // eyes
  fill(255);
  ellipse(eyeX, 180, 30, 20);           
  ellipse(eyeX + 60, 180, 30, 20);      

  // pupils 
  fill(0);
  circle(pupilX, pupilY, 10);          
  circle(pupilX + 60, pupilY, 10);     

  // nose
  noFill();
  triangle(180, 220, 220, 220, 200, 190);
  strokeWeight(4);
  // nostrils 
  point(190, nostrilY);
  point(210, nostrilY);
  strokeWeight(1); 

  // mouth
  line(180, 250, 220, 250);

  // signature
  fill(50);
  textSize(16);
  textAlign(RIGHT);
  text("- Cameron Martin", 380, 380);
}